from bluepy import btle
from csv import writer
import csv
from datetime import datetime

mac1 = "30:AE:A4:8F:1D:02"
mac2 = "7c:9E:BD:45:12:9A"


