#!bin/bash

bluetoothctl scan on | grep 30:AE:A4:8F:1D:02
