#!/bin/bash
cd /home/pi/AIRQINO && python3 read_Zone1_BLE_server2.py && python3 read_Zone2_BLE_server2.py
