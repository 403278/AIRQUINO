#!/bin/bash
cd /home/pi/AIRQINO && sleep 20 && python3 read_Zone1_BLE_server.py
