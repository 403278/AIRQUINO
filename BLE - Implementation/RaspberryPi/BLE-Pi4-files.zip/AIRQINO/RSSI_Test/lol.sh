#!/bin/bash

seconds=0

bluetoothctl scan on | grep 7C:9E:BD:45:12:9A
