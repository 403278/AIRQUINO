#!/bin/bash
cd /home/pi/AIRQINO && python3 read_Zone2_BLE_server4.py
