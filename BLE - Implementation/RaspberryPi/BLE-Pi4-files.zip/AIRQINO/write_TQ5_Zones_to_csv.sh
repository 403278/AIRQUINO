#!/bin/bash
cd /home/pi/AIRQINO && bash write_TQ5_Zone1_to_csv.sh && bash write_TQ5_Zone2_to_csv.sh
