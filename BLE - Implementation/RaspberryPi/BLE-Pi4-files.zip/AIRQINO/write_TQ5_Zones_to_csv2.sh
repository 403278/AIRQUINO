#!/bin/bash
cd /home/pi/AIRQINO && bash write_TQ5_Zone1_to_csv2.sh && bash write_TQ5_Zone2_to_csv2.sh
