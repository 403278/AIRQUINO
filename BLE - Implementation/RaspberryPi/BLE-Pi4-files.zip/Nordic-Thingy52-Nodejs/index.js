module.exports = require('./lib/thingy');
