=========
listen.py
=========

.. automodule:: examples.listen

**Source:**

.. literalinclude:: ../../examples/listen.py
