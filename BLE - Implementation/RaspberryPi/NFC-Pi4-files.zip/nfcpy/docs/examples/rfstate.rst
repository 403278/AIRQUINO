==========
rfstate.py
==========

.. automodule:: examples.rfstate

**Source:**

.. literalinclude:: ../../examples/rfstate.py
