nfc.handover
============

.. automodule:: nfc.handover

nfc.handover.HandoverServer
---------------------------

.. autoclass:: HandoverServer
   :members:

nfc.handover.HandoverClient
---------------------------

.. autoclass:: HandoverClient
   :members:

