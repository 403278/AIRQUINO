nfc.snep
========

.. automodule:: nfc.snep

nfc.snep.SnepServer
-------------------

.. autoclass:: SnepServer
   :members:

nfc.snep.SnepClient
-------------------

.. autoclass:: SnepClient
   :members:
