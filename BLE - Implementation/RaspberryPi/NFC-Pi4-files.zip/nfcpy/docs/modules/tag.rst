nfc.tag
=======

.. contents::
   :local:

.. automodule:: nfc.tag
   :show-inheritance:
   :members:

Type 1 Tag
----------

.. automodule:: nfc.tag.tt1
   :show-inheritance:
   :members:

.. automodule:: nfc.tag.tt1_broadcom
   :show-inheritance:
   :members:

Type 2 Tag
----------

.. automodule:: nfc.tag.tt2
   :show-inheritance:
   :members:

.. automodule:: nfc.tag.tt2_nxp
   :show-inheritance:
   :members:

Type 3 Tag
----------

.. automodule:: nfc.tag.tt3
   :show-inheritance:
   :members:

.. automodule:: nfc.tag.tt3_sony
   :show-inheritance:
   :members:

Type 4 Tag
----------

.. automodule:: nfc.tag.tt4
   :show-inheritance:
   :members:

