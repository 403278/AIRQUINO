#!/bin/sh

i2cdetect -y 1
