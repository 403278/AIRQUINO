"""
    Communication tests for the various interfaces
"""