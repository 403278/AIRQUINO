"""
    Functional tests (for testing with an actual pn533)
"""
