"""
    Unit tests for integration testing (can run independent of hardware)
"""